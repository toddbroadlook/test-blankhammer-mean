Blog Post -> http://mherman.org/blog/2015/07/02/handling-user-authentication-with-the-mean-stack
